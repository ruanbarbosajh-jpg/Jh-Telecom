/* JH TELECOM — Monitoramento OLT · SERVICE WORKER (03/10/2026)
 *
 * Lê o AutoISP da Alloha (auto.alloha.com) com o login que já está neste Chrome — a JH é
 * terceirizada da Alloha e só LÊ:
 *   • /olts/olts_list?olt_city=<6 cidades da JH Litoral>  → OLTs (conexão, monitoramento, auditoria)
 *   • /provisioned_onus_datatable.json, por OLT ativa × situação do sinal → ONUs Crítico, Atenção,
 *     LoS, Sem energia, LoS/energia em massa
 * Só GET, no máximo 3 consultas ao mesmo tempo. NÃO abre a página de cada cliente (ela faz a
 * OLT consultar o equipamento) e NÃO lê senha nenhuma (PPPoE / Wi-Fi ficam no AutoISP).
 * Mesma lógica do deploy/coletor-olt.js (o favorito) — se mudar uma, mude a outra.
 */
'use strict';
const BASE = 'https://auto.alloha.com';
const CIDADES = ['Guaruja', 'Santos', 'Sao Vicente', 'Bertioga', 'Cubatao', 'Praia Grande'];
const SITUACOES = ['critical', 'warning', 'loss_signal', 'power_fail', 'massive_loss_signal', 'massive_power_fail'];
const COLUNAS = ['signal', 'signal', 'serial_number', 'circuit_id', 'int6_id', 'name', 'description', 'olt', 'ponlink', 'onu_id', 'onu_type', 'onu_info_model', 'topology'];
const POR_PAGINA = 100;
const PARALELO = 3;
let EM_ANDAMENTO = false;

async function pegar(caminho) {
  let r;
  try {
    r = await fetch(BASE + caminho, { credentials: 'include', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
  } catch (e) { throw new Error('Não consegui falar com o AutoISP (sem internet?).'); }
  const tipo = r.headers.get('content-type') || '';
  if (r.status === 401 || r.status === 403 || (r.redirected && /sign_in/.test(r.url)) || !/json/.test(tipo)) {
    throw new Error('Entre no AutoISP (auto.alloha.com) neste Chrome e clique de novo em Atualizar.');
  }
  if (!r.ok) throw new Error('AutoISP respondeu ' + r.status + ' em ' + caminho.split('?')[0]);
  return r.json();
}
function urlOnus(oltId, situacao, inicio) {
  const p = new URLSearchParams();
  p.set('draw', '1');
  COLUNAS.forEach((c, i) => {
    p.set(`columns[${i}][data]`, c); p.set(`columns[${i}][name]`, '');
    p.set(`columns[${i}][searchable]`, i === 0 ? 'false' : 'true');
    p.set(`columns[${i}][orderable]`, i <= 1 ? 'false' : 'true');
    p.set(`columns[${i}][search][value]`, i === 1 ? situacao : (i === 7 ? String(oltId) : ''));
    p.set(`columns[${i}][search][regex]`, 'false');
  });
  p.set('order[0][column]', '3'); p.set('order[0][dir]', 'asc');
  p.set('start', String(inicio)); p.set('length', String(POR_PAGINA));
  p.set('search[value]', ''); p.set('search[regex]', 'false');
  return '/provisioned_onus_datatable.json?' + p.toString();
}
const kind = o => o && typeof o === 'object' ? String(o.kind || o.status || '') : String(o || '');
const dica = o => o && typeof o === 'object' ? String(o.tooltip || '') : '';
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : null; };
const link = v => typeof v === 'string' && v.indexOf(BASE + '/') === 0 ? v : '';
async function emFila(tarefas, limite, aoAndar) {
  const resultados = new Array(tarefas.length);
  let i = 0, feitas = 0;
  async function trabalhador() {
    while (i < tarefas.length) {
      const k = i++;
      try { resultados[k] = await tarefas[k](); } catch (e) { resultados[k] = { erro: String(e && e.message || e) }; }
      feitas++; aoAndar(feitas, tarefas.length);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limite, tarefas.length) }, trabalhador));
  return resultados;
}

async function coletar(avisar) {
  avisar('Lendo a lista de OLTs das cidades da JH…', 2);
  const base = '/olts/olts_list?olt_city=' + encodeURIComponent(CIDADES.join(',')) + '&sort_field=hostname&sort_order=asc&hide_deactivated=false&items=100&page=';
  const lista = [];
  let pagina = 1, total = Infinity;
  while (lista.length < total && pagina <= 20) {
    const j = await pegar(base + pagina);
    total = j.total_count || 0;
    (j.olts || []).forEach(o => lista.push(o));
    if (!j.olts || !j.olts.length) break;
    pagina++;
  }
  const olts = lista.map(o => ({
    id: o.id, hostname: o.hostname || '', modelo: o.model || '', modo: o.operation_mode || '',
    conexao: kind(o.connection_status), conexao_info: dica(o.connection_status),
    auditoria: kind(o.audit_status), monitoramento: kind(o.zabbix_status),
    ip: o.ip || '', clientes: o.sum_onus || 0, onus_lidas: o.sum_onus_olt || 0,
    cidades: String(o.locations_text || '').split('\n').map(s => s.trim()).filter(Boolean),
    ultima_config: o.running_cfg_last_changed || '',
  }));
  // DEACTIV (desativada) não conta — pedido do cliente
  const ativas = olts.filter(o => !/deactiv/i.test(o.modo));
  const onus = [], erros = [], vistos = new Set();
  async function rodar(tarefas, rotulo, de, ate) {
    const res = await emFila(tarefas.map(t => () => pegar(urlOnus(t.olt.id, t.sit, t.inicio))), PARALELO,
      (f, n) => avisar(`${rotulo} ${f} de ${n}…`, de + (ate - de) * f / n));
    const extras = [];
    res.forEach((r, k) => {
      const t = tarefas[k];
      if (!r || r.erro) { erros.push(`${t.olt.hostname || t.olt.id} / ${t.sit}: ${r && r.erro || 'sem resposta'}`); return; }
      (r.data || []).forEach(x => {
        const sinal = Array.isArray(x.signal) ? x.signal : [null, null];
        const sn = Array.isArray(x.serial_number) ? x.serial_number : [];
        const chave = `${sn[0] || ''}|${t.olt.id}|${x.ponlink}|${x.onu_id}`;
        if (vistos.has(chave)) return;
        vistos.add(chave);
        onus.push({
          olt_id: t.olt.id, olt: (Array.isArray(x.olt) ? x.olt[0] : '') || t.olt.hostname, ponlink: x.ponlink || '', onu_id: x.onu_id,
          situacao: sinal[1] || t.sit, sinal: num(sinal[0]),
          serial: sn[0] || '', link: link(sn[2]),
          contrato: Array.isArray(x.circuit_id) ? x.circuit_id[0] : null, int6: Array.isArray(x.int6_id) ? x.int6_id[0] : null,
          nome: x.name || '', descricao: x.description || '', modelo: x.onu_info_model || x.onu_type || '',
        });
      });
      if (t.inicio === 0) {
        const tot = r.recordsFiltered || 0;
        for (let ini = POR_PAGINA; ini < tot && ini < 5000; ini += POR_PAGINA) extras.push({ olt: t.olt, sit: t.sit, inicio: ini });
      }
    });
    return extras;
  }
  const tarefas = [];
  ativas.forEach(o => SITUACOES.forEach(s => tarefas.push({ olt: o, sit: s, inicio: 0 })));
  const extras = await rodar(tarefas, `${ativas.length} OLTs · consultando`, 5, 90);
  if (extras.length) await rodar(extras, 'Páginas extras', 90, 99);
  return { tipo: 'jh-monitor-olt', versao: 1, origem: 'auto.alloha.com', coletado_em: new Date().toISOString(), cidades: CIDADES, olts, onus, erros };
}

chrome.runtime.onConnect.addListener(porta => {
  if (porta.name !== 'coleta-olt') return;
  porta.onMessage.addListener(async m => {
    if (!m || m.acao !== 'coletar') return;
    if (EM_ANDAMENTO) { porta.postMessage({ tipo: 'jh-ext-erro', erro: 'Já tem uma atualização em andamento — espere terminar.' }); return; }
    EM_ANDAMENTO = true;
    // as mensagens de progresso pela porta mantêm o service worker acordado (a coleta leva ~1 min)
    const avisar = (texto, pct) => { try { porta.postMessage({ tipo: 'jh-ext-progresso', texto, pct: Math.round(pct) }); } catch (e) { /* página fechou */ } };
    try {
      const dados = await coletar(avisar);
      porta.postMessage({ tipo: 'jh-ext-resultado', dados });
    } catch (e) {
      try { porta.postMessage({ tipo: 'jh-ext-erro', erro: String(e && e.message || e) }); } catch (x) { /* página fechou */ }
    } finally {
      EM_ANDAMENTO = false;
    }
  });
});
