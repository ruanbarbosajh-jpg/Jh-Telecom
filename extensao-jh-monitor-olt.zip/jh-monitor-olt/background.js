/* JH TELECOM — Monitoramento OLT · SERVICE WORKER (03/10/2026)
 *
 * Lê o AutoISP da Alloha (auto.alloha.com) com o login que já está neste Chrome — a JH é
 * terceirizada da Alloha e só LÊ:
 *   • /olts/olts_list?olt_city=<6 cidades da JH Litoral>  → OLTs (conexão, monitoramento, auditoria)
 *   • /provisioned_onus_datatable.json, por OLT ativa × situação do sinal → ONUs Crítico, Atenção,
 *     LoS, Sem energia, LoS/energia em massa
 * Só GET, no máximo 3 consultas ao mesmo tempo. NÃO abre a página de cada cliente (ela faz a
 * OLT consultar o equipamento) e NÃO lê senha nenhuma (PPPoE / Wi-Fi ficam no AutoISP).
 * Mesma lógica do deploy/coletor-olt.js (o favorito) — se mudar uma, mude a outra.
 */
'use strict';
const BASE = 'https://auto.alloha.com';
const CIDADES = ['Guaruja', 'Santos', 'Sao Vicente', 'Bertioga', 'Cubatao', 'Praia Grande'];
const SITUACOES = ['critical', 'warning', 'loss_signal', 'power_fail', 'massive_loss_signal', 'massive_power_fail'];
const COLUNAS = ['signal', 'signal', 'serial_number', 'circuit_id', 'int6_id', 'name', 'description', 'olt', 'ponlink', 'onu_id', 'onu_type', 'onu_info_model', 'topology'];
const POR_PAGINA = 100;
const PARALELO = 3;
let EM_ANDAMENTO = false;

async function pegar(caminho) {
  let r;
  try {
    r = await fetch(BASE + caminho, { credentials: 'include', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
  } catch (e) { throw new Error('Não consegui falar com o AutoISP (sem internet?).'); }
  const tipo = r.headers.get('content-type') || '';
  if (r.status === 401 || r.status === 403 || (r.redirected && /sign_in/.test(r.url)) || !/json/.test(tipo)) {
    throw new Error('Entre no AutoISP (auto.alloha.com) neste Chrome e clique de novo em Atualizar.');
  }
  if (!r.ok) throw new Error('AutoISP respondeu ' + r.status + ' em ' + caminho.split('?')[0]);
  return r.json();
}
function urlOnus(oltId, situacao, inicio) {
  const p = new URLSearchParams();
  p.set('draw', '1');
  COLUNAS.forEach((c, i) => {
    p.set(`columns[${i}][data]`, c); p.set(`columns[${i}][name]`, '');
    p.set(`columns[${i}][searchable]`, i === 0 ? 'false' : 'true');
    p.set(`columns[${i}][orderable]`, i <= 1 ? 'false' : 'true');
    p.set(`columns[${i}][search][value]`, i === 1 ? situacao : (i === 7 ? String(oltId) : ''));
    p.set(`columns[${i}][search][regex]`, 'false');
  });
  p.set('order[0][column]', '3'); p.set('order[0][dir]', 'asc');
  p.set('start', String(inicio)); p.set('length', String(POR_PAGINA));
  p.set('search[value]', ''); p.set('search[regex]', 'false');
  return '/provisioned_onus_datatable.json?' + p.toString();
}
const kind = o => o && typeof o === 'object' ? String(o.kind || o.status || '') : String(o || '');
const dica = o => o && typeof o === 'object' ? String(o.tooltip || '') : '';
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : null; };
const link = v => typeof v === 'string' && v.indexOf(BASE + '/') === 0 ? v : '';
async function emFila(tarefas, limite, aoAndar) {
  const resultados = new Array(tarefas.length);
  let i = 0, feitas = 0;
  async function trabalhador() {
    while (i < tarefas.length) {
      const k = i++;
      try { resultados[k] = await tarefas[k](); } catch (e) { resultados[k] = { erro: String(e && e.message || e) }; }
      feitas++; aoAndar(feitas, tarefas.length);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limite, tarefas.length) }, trabalhador));
  return resultados;
}

async function coletar(avisar) {
  avisar('Lendo a lista de OLTs das cidades da JH…', 2);
  const base = '/olts/olts_list?olt_city=' + encodeURIComponent(CIDADES.join(',')) + '&sort_field=hostname&sort_order=asc&hide_deactivated=false&items=100&page=';
  const lista = [];
  let pagina = 1, total = Infinity;
  while (lista.length < total && pagina <= 20) {
    const j = await pegar(base + pagina);
    total = j.total_count || 0;
    (j.olts || []).forEach(o => lista.push(o));
    if (!j.olts || !j.olts.length) break;
    pagina++;
  }
  const olts = lista.map(o => ({
    id: o.id, hostname: o.hostname || '', modelo: o.model || '', modo: o.operation_mode || '',
    conexao: kind(o.connection_status), conexao_info: dica(o.connection_status),
    auditoria: kind(o.audit_status), monitoramento: kind(o.zabbix_status),
    ip: o.ip || '', clientes: o.sum_onus || 0, onus_lidas: o.sum_onus_olt || 0,
    cidades: String(o.locations_text || '').split('\n').map(s => s.trim()).filter(Boolean),
    ultima_config: o.running_cfg_last_changed || '',
  }));
  // DEACTIV (desativada) não conta — pedido do cliente
  const ativas = olts.filter(o => !/deactiv/i.test(o.modo));
  const onus = [], erros = [], vistos = new Set();
  async function rodar(tarefas, rotulo, de, ate) {
    const res = await emFila(tarefas.map(t => () => pegar(urlOnus(t.olt.id, t.sit, t.inicio))), PARALELO,
      (f, n) => avisar(`${rotulo} ${f} de ${n}…`, de + (ate - de) * f / n));
    const extras = [];
    res.forEach((r, k) => {
      const t = tarefas[k];
      if (!r || r.erro) { erros.push(`${t.olt.hostname || t.olt.id} / ${t.sit}: ${r && r.erro || 'sem resposta'}`); return; }
      (r.data || []).forEach(x => {
        const sinal = Array.isArray(x.signal) ? x.signal : [null, null];
        const sn = Array.isArray(x.serial_number) ? x.serial_number : [];
        const chave = `${sn[0] || ''}|${t.olt.id}|${x.ponlink}|${x.onu_id}`;
        if (vistos.has(chave)) return;
        vistos.add(chave);
        onus.push({
          olt_id: t.olt.id, olt: (Array.isArray(x.olt) ? x.olt[0] : '') || t.olt.hostname, ponlink: x.ponlink || '', onu_id: x.onu_id,
          situacao: sinal[1] || t.sit, sinal: num(sinal[0]),
          serial: sn[0] || '', link: link(sn[2]),
          contrato: Array.isArray(x.circuit_id) ? x.circuit_id[0] : null, int6: Array.isArray(x.int6_id) ? x.int6_id[0] : null,
          nome: x.name || '', descricao: x.description || '', modelo: x.onu_info_model || x.onu_type || '',
        });
      });
      if (t.inicio === 0) {
        const tot = r.recordsFiltered || 0;
        for (let ini = POR_PAGINA; ini < tot && ini < 5000; ini += POR_PAGINA) extras.push({ olt: t.olt, sit: t.sit, inicio: ini });
      }
    });
    return extras;
  }
  const tarefas = [];
  ativas.forEach(o => SITUACOES.forEach(s => tarefas.push({ olt: o, sit: s, inicio: 0 })));
  const extras = await rodar(tarefas, `${ativas.length} OLTs · consultando`, 5, 90);
  if (extras.length) await rodar(extras, 'Páginas extras', 90, 99);
  return { tipo: 'jh-monitor-olt', versao: 1, origem: 'auto.alloha.com', coletado_em: new Date().toISOString(), cidades: CIDADES, olts, onus, erros };
}

// ---- CONSULTAS PONTUAIS (versão 1.1.0, 05/10/2026) ----
// Pedido do cliente: pesquisar QUALQUER assinante (não só as ONUs com sinal ruim) por nome,
// contrato etc. e ver o sinal dele. É a mesma coisa que a "Busca de Assinantes" do AutoISP faz
// quando alguém digita nos filtros e abre uma linha: só GET, uma consulta por vez.
//   /client_search/search?...           → lista (no máximo 100 por consulta, limite do próprio AutoISP)
//   /gpon_clients/<int6>/detailed_info  → detalhes: sinal Rx, status, último contato do equipamento (ACS),
//                                         endereço e coordenadas. NÃO é a página do cliente (essa manda a
//                                         OLT/ACS consultar o equipamento) e NÃO traz CPF/CNPJ pra cá:
//                                         o JSON tem esses campos e eles são descartados aqui.
// A busca é SEMPRE limitada às OLTs das 6 cidades da JH (olt_id = lista separada por vírgula), senão
// voltaria assinante do Brasil inteiro.
const CACHE_OLTS = { quando: 0, ids: [] };
async function idsOltsDaJh() {
  if (CACHE_OLTS.ids.length && Date.now() - CACHE_OLTS.quando < 30 * 60 * 1000) return CACHE_OLTS.ids;
  const base = '/olts/olts_list?olt_city=' + encodeURIComponent(CIDADES.join(',')) + '&sort_field=hostname&sort_order=asc&hide_deactivated=false&items=100&page=';
  const ids = [];
  let pagina = 1, total = Infinity;
  while (ids.length < total && pagina <= 20) {
    const j = await pegar(base + pagina);
    total = j.total_count || 0;
    (j.olts || []).forEach(o => { if (o && o.id != null) ids.push(o.id); });
    if (!j.olts || !j.olts.length) break;
    pagina++;
  }
  if (!ids.length) throw new Error('Não achei as OLTs da JH no AutoISP.');
  CACHE_OLTS.ids = ids; CACHE_OLTS.quando = Date.now();
  return ids;
}
const txt = (v, n) => v == null ? '' : String(v).slice(0, n || 200);
const FILTROS_BUSCA = { nome: 'subscriber_name', contrato: 'erp_id', pppoe: 'pppoe_username', endereco: 'address', serial: 'serial_number', int6: 'gpon_client_id' };
async function buscarAssinantes(f) {
  const p = new URLSearchParams();
  let algum = false;
  Object.keys(FILTROS_BUSCA).forEach(k => {
    const v = String((f && f[k]) || '').trim().slice(0, 80);
    if (v) { p.set(FILTROS_BUSCA[k], v); algum = true; }
  });
  if (!algum) throw new Error('Digite pelo menos um filtro (nome, contrato, PPPoE, endereço, SN ou Int6).');
  p.set('olt_id', (await idsOltsDaJh()).join(','));
  const j = await pegar('/client_search/search?' + p.toString());
  if (!Array.isArray(j)) throw new Error('O AutoISP respondeu num formato que eu não conheço.');
  return j.slice(0, 100).map(x => ({
    int6: txt(x.gpon_client_id, 20), contrato: txt(x.erp_id, 30), nome: txt(x.subscriber_name, 120), pppoe: txt(x.pppoe_username, 80),
    endereco: txt(x.address, 200), serial: txt(x.serial_number, 60), serial_curto: txt(x.short_serial_number, 30),
    acs: txt(x.acs_serial_number, 40), olt: txt(x.olt_hostname, 120), olt_id: txt(x.olt_id, 20), ponlink: txt(x.ponlink, 20),
  }));
}
async function detalheAssinante(int6) {
  const id = String(int6 || '').trim();
  if (!/^\d{1,12}$/.test(id)) throw new Error('Int6 inválido.');
  const j = await pegar('/gpon_clients/' + id + '/detailed_info');
  const g = j && j.gpon_client;
  if (!g) throw new Error('O AutoISP não devolveu os detalhes desse assinante.');
  const c = (g.contracted_service && g.contracted_service.contract) || {};
  const sub = c.subscriber || {};
  const st = g.onu_status || {};
  const rx = parseFloat(String(st.rx_power).replace(',', '.'));
  const co = j.coordinates && j.coordinates.client;
  return {
    int6: id, ponlink: txt(g.ponlink, 20), serial: txt(g.serial_number, 60), mac: txt(g.mac, 40), descricao: txt(g.description, 160),
    pppoe: txt(g.pppoe_username, 80), topologia: txt(g.topology, 30),
    plano: txt(g.contracted_service && g.contracted_service.service && g.contracted_service.service.service_name, 200),
    contrato: txt(c.contract_code, 30), nome: txt(sub.subsc_corp_name || sub.subsc_name, 120),
    bairro: txt(c.contract_install_addr_neigh, 80), cidade: txt(c.contract_install_addr_city, 60), uf: txt(c.contract_install_addr_state, 4),
    sinal_rx: isFinite(rx) ? rx : null, status_onu: txt(st.status, 40),
    acs_ultimo_contato: txt(g.acs_last_inform, 40), acs_serial: txt(g.acs_serial_number, 40), registro_atualizado_em: txt(g.updated_at, 40),
    macs: (Array.isArray(g.learned_macs) ? g.learned_macs : []).map(m => txt(m && m.mac, 30)).slice(0, 10),
    lat: co && isFinite(Number(co.lat)) ? Number(co.lat) : null, lng: co && isFinite(Number(co.lng)) ? Number(co.lng) : null,
    consultado_em: new Date().toISOString(),
  };
}

// ---- ENVIAR SESSÃO (versão 1.2.0, 05/10/2026) ----
// Pedido do cliente: o AutoISP "24 h", atualizado de 30 em 30 min pela nuvem, sem PC ligado. O AutoISP não
// tem API: o coletor da nuvem (Edge Function "autoisp" do Supabase) usa a MESMA sessão deste Chrome. Os
// cookies de login são HttpOnly (a página não os lê) — só uma extensão com a permissão "cookies" lê.
// Eles vão SÓ pro Supabase do próprio sistema JH (tabela trancada), por quem é Supervisor/Coordenador/Analista.
// Nenhuma senha é lida: só os cookies que o AutoISP já deixou neste navegador.
async function lerSessaoAutoIsp() {
  const lista = await chrome.cookies.getAll({ domain: 'auto.alloha.com' });
  const cookies = {};
  lista.forEach(c => { if (c && c.name && c.value) cookies[c.name] = c.value; });
  if (!Object.keys(cookies).length) throw new Error('Não há login do AutoISP neste Chrome. Entre em auto.alloha.com e tente de novo.');
  return { cookies, quantos: Object.keys(cookies).length };
}

chrome.runtime.onConnect.addListener(porta => {
  if (porta.name === 'consulta-olt') {
    porta.onMessage.addListener(async m => {
      if (!m || (m.acao !== 'buscar' && m.acao !== 'detalhe' && m.acao !== 'sessao')) return;
      try {
        const dados = m.acao === 'sessao' ? await lerSessaoAutoIsp() : m.acao === 'buscar' ? await buscarAssinantes(m.args) : await detalheAssinante(m.args && m.args.int6);
        porta.postMessage({ tipo: 'jh-ext-consulta-resp', ok: true, dados });
      } catch (e) {
        try { porta.postMessage({ tipo: 'jh-ext-consulta-resp', ok: false, erro: String(e && e.message || e) }); } catch (x) { /* página fechou */ }
      }
    });
    return;
  }
  // (coleta completa das OLTs/ONUs, a de sempre)
  if (porta.name !== 'coleta-olt') return;
  porta.onMessage.addListener(async m => {
    if (!m || m.acao !== 'coletar') return;
    if (EM_ANDAMENTO) { porta.postMessage({ tipo: 'jh-ext-erro', erro: 'Já tem uma atualização em andamento — espere terminar.' }); return; }
    EM_ANDAMENTO = true;
    // as mensagens de progresso pela porta mantêm o service worker acordado (a coleta leva ~1 min)
    const avisar = (texto, pct) => { try { porta.postMessage({ tipo: 'jh-ext-progresso', texto, pct: Math.round(pct) }); } catch (e) { /* página fechou */ } };
    try {
      const dados = await coletar(avisar);
      porta.postMessage({ tipo: 'jh-ext-resultado', dados });
    } catch (e) {
      try { porta.postMessage({ tipo: 'jh-ext-erro', erro: String(e && e.message || e) }); } catch (x) { /* página fechou */ }
    } finally {
      EM_ANDAMENTO = false;
    }
  });
});
