/* JH TELECOM — Monitoramento OLT · SERVICE WORKER (03/10/2026)
 *
 * Lê o AutoISP da Alloha (auto.alloha.com) com o login que já está neste Chrome — a JH é
 * terceirizada da Alloha e só LÊ:
 *   • /olts/olts_list?olt_city=<6 cidades da JH Litoral>  → OLTs (conexão, monitoramento, auditoria)
 *   • /provisioned_onus_datatable.json, por OLT ativa × situação do sinal → ONUs Crítico, Atenção,
 *     LoS, Sem energia, LoS/energia em massa
 * Só GET, no máximo 3 consultas ao mesmo tempo. NÃO abre a página de cada cliente (ela faz a
 * OLT consultar o equipamento) e NÃO lê senha nenhuma (PPPoE / Wi-Fi ficam no AutoISP).
 * Mesma lógica do deploy/coletor-olt.js (o favorito) — se mudar uma, mude a outra.
 */
'use strict';
const BASE = 'https://auto.alloha.com';
const CIDADES = ['Guaruja', 'Santos', 'Sao Vicente', 'Bertioga', 'Cubatao', 'Praia Grande'];
const SITUACOES = ['critical', 'warning', 'loss_signal', 'power_fail', 'massive_loss_signal', 'massive_power_fail'];
const COLUNAS = ['signal', 'signal', 'serial_number', 'circuit_id', 'int6_id', 'name', 'description', 'olt', 'ponlink', 'onu_id', 'onu_type', 'onu_info_model', 'topology'];
const POR_PAGINA = 100;
const PARALELO = 3;
let EM_ANDAMENTO = false;

async function pegar(caminho) {
  let r;
  try {
    r = await fetch(BASE + caminho, { credentials: 'include', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
  } catch (e) { throw new Error('Não consegui falar com o AutoISP (sem internet?).'); }
  const tipo = r.headers.get('content-type') || '';
  if (r.status === 401 || r.status === 403 || (r.redirected && /sign_in/.test(r.url)) || !/json/.test(tipo)) {
    throw new Error('Entre no AutoISP (auto.alloha.com) neste Chrome e clique de novo em Atualizar.');
  }
  if (!r.ok) throw new Error('AutoISP respondeu ' + r.status + ' em ' + caminho.split('?')[0]);
  return r.json();
}
function urlOnus(oltId, situacao, inicio) {
  const p = new URLSearchParams();
  p.set('draw', '1');
  COLUNAS.forEach((c, i) => {
    p.set(`columns[${i}][data]`, c); p.set(`columns[${i}][name]`, '');
    p.set(`columns[${i}][searchable]`, i === 0 ? 'false' : 'true');
    p.set(`columns[${i}][orderable]`, i <= 1 ? 'false' : 'true');
    p.set(`columns[${i}][search][value]`, i === 1 ? situacao : (i === 7 ? String(oltId) : ''));
    p.set(`columns[${i}][search][regex]`, 'false');
  });
  p.set('order[0][column]', '3'); p.set('order[0][dir]', 'asc');
  p.set('start', String(inicio)); p.set('length', String(POR_PAGINA));
  p.set('search[value]', ''); p.set('search[regex]', 'false');
  return '/provisioned_onus_datatable.json?' + p.toString();
}
const kind = o => o && typeof o === 'object' ? String(o.kind || o.status || '') : String(o || '');
const dica = o => o && typeof o === 'object' ? String(o.tooltip || '') : '';
const num = v => { const n = parseFloat(String(v).replace(',', '.')); return isFinite(n) ? n : null; };
const link = v => typeof v === 'string' && v.indexOf(BASE + '/') === 0 ? v : '';
async function emFila(tarefas, limite, aoAndar) {
  const resultados = new Array(tarefas.length);
  let i = 0, feitas = 0;
  async function trabalhador() {
    while (i < tarefas.length) {
      const k = i++;
      try { resultados[k] = await tarefas[k](); } catch (e) { resultados[k] = { erro: String(e && e.message || e) }; }
      feitas++; aoAndar(feitas, tarefas.length);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limite, tarefas.length) }, trabalhador));
  return resultados;
}

async function coletar(avisar) {
  avisar('Lendo a lista de OLTs das cidades da JH…', 2);
  const base = '/olts/olts_list?olt_city=' + encodeURIComponent(CIDADES.join(',')) + '&sort_field=hostname&sort_order=asc&hide_deactivated=false&items=100&page=';
  const lista = [];
  let pagina = 1, total = Infinity;
  while (lista.length < total && pagina <= 20) {
    const j = await pegar(base + pagina);
    total = j.total_count || 0;
    (j.olts || []).forEach(o => lista.push(o));
    if (!j.olts || !j.olts.length) break;
    pagina++;
  }
  const olts = lista.map(o => ({
    id: o.id, hostname: o.hostname || '', modelo: o.model || '', modo: o.operation_mode || '',
    conexao: kind(o.connection_status), conexao_info: dica(o.connection_status),
    auditoria: kind(o.audit_status), monitoramento: kind(o.zabbix_status),
    ip: o.ip || '', clientes: o.sum_onus || 0, onus_lidas: o.sum_onus_olt || 0,
    cidades: String(o.locations_text || '').split('\n').map(s => s.trim()).filter(Boolean),
    ultima_config: o.running_cfg_last_changed || '',
  }));
  // DEACTIV (desativada) não conta — pedido do cliente
  const ativas = olts.filter(o => !/deactiv/i.test(o.modo));
  const onus = [], erros = [], vistos = new Set();
  async function rodar(tarefas, rotulo, de, ate) {
    const res = await emFila(tarefas.map(t => () => pegar(urlOnus(t.olt.id, t.sit, t.inicio))), PARALELO,
      (f, n) => avisar(`${rotulo} ${f} de ${n}…`, de + (ate - de) * f / n));
    const extras = [];
    res.forEach((r, k) => {
      const t = tarefas[k];
      if (!r || r.erro) { erros.push(`${t.olt.hostname || t.olt.id} / ${t.sit}: ${r && r.erro || 'sem resposta'}`); return; }
      (r.data || []).forEach(x => {
        const sinal = Array.isArray(x.signal) ? x.signal : [null, null];
        const sn = Array.isArray(x.serial_number) ? x.serial_number : [];
        const chave = `${sn[0] || ''}|${t.olt.id}|${x.ponlink}|${x.onu_id}`;
        if (vistos.has(chave)) return;
        vistos.add(chave);
        onus.push({
          olt_id: t.olt.id, olt: (Array.isArray(x.olt) ? x.olt[0] : '') || t.olt.hostname, ponlink: x.ponlink || '', onu_id: x.onu_id,
          situacao: sinal[1] || t.sit, sinal: num(sinal[0]),
          serial: sn[0] || '', link: link(sn[2]),
          contrato: Array.isArray(x.circuit_id) ? x.circuit_id[0] : null, int6: Array.isArray(x.int6_id) ? x.int6_id[0] : null,
          nome: x.name || '', descricao: x.description || '', modelo: x.onu_info_model || x.onu_type || '',
        });
      });
      if (t.inicio === 0) {
        const tot = r.recordsFiltered || 0;
        for (let ini = POR_PAGINA; ini < tot && ini < 5000; ini += POR_PAGINA) extras.push({ olt: t.olt, sit: t.sit, inicio: ini });
      }
    });
    return extras;
  }
  const tarefas = [];
  ativas.forEach(o => SITUACOES.forEach(s => tarefas.push({ olt: o, sit: s, inicio: 0 })));
  const extras = await rodar(tarefas, `${ativas.length} OLTs · consultando`, 5, 90);
  if (extras.length) await rodar(extras, 'Páginas extras', 90, 99);
  return { tipo: 'jh-monitor-olt', versao: 1, origem: 'auto.alloha.com', coletado_em: new Date().toISOString(), cidades: CIDADES, olts, onus, erros };
}

// ---- CONSULTAS PONTUAIS (versão 1.1.0, 05/10/2026) ----
// Pedido do cliente: pesquisar QUALQUER assinante (não só as ONUs com sinal ruim) por nome,
// contrato etc. e ver o sinal dele. É a mesma coisa que a "Busca de Assinantes" do AutoISP faz
// quando alguém digita nos filtros e abre uma linha: só GET, uma consulta por vez.
//   /client_search/search?...           → lista (no máximo 100 por consulta, limite do próprio AutoISP)
//   /gpon_clients/<int6>/detailed_info  → detalhes: sinal Rx, status, último contato do equipamento (ACS),
//                                         endereço e coordenadas. NÃO é a página do cliente (essa manda a
//                                         OLT/ACS consultar o equipamento) e NÃO traz CPF/CNPJ pra cá:
//                                         o JSON tem esses campos e eles são descartados aqui.
// A busca é SEMPRE limitada às OLTs das 6 cidades da JH (olt_id = lista separada por vírgula), senão
// voltaria assinante do Brasil inteiro.
const CACHE_OLTS = { quando: 0, ids: [], lista: [] };
// v1.3.0: guarda também o nome (hostname) de cada OLT — a busca por OLT/PON e a lista de OLTs precisam.
// 20/10/2026: o AutoISP deixou a conta só com "Busca de Assinantes" e "ONUs" (sem o menu de OLTs), então a lista agora vem de
// /olts/get_all_for_select — a mesma que alimenta o filtro "OLT" da Busca de Assinantes. Se ela não responder, tenta a lista antiga
// (/olts/olts_list); se nenhuma responder, a busca segue SEM restringir por OLT (lista vazia) em vez de quebrar.
// Só ficam as OLTs das 6 cidades da JH pelo código no nome (-SAN-, -GRJ-, -SVC-, -CBT-, -BRT-, -PGR-).
const COD_CIDADES_JH = /(^|[-_ ])(SAN|GRJ|SVC|CBT|BRT|PGR)([-_ ]|$)/i;
function normalizaOlts(j) {
  let arr = Array.isArray(j) ? j : (j && (j.olts || j.data || j.items)) || [];
  if (!Array.isArray(arr)) arr = [];
  return arr.map(x => {
    if (Array.isArray(x)) return { id: x[0], hostname: txt(x[1], 120) };
    if (!x || typeof x !== 'object') return null;
    const id = x.id != null ? x.id : x.value;
    const nome = x.hostname || x.label || x.name || x.text || x.title || '';
    return id == null ? null : { id, hostname: txt(nome, 120), modelo: txt(x.model, 40), modo: txt(x.operation_mode, 30), conexao: kind(x.connection_status), clientes: x.sum_onus || 0 };
  }).filter(o => o && o.hostname);
}
async function oltsDaJh() {
  if (CACHE_OLTS.lista.length && Date.now() - CACHE_OLTS.quando < 30 * 60 * 1000) return CACHE_OLTS.lista;
  let lista = [];
  try { lista = normalizaOlts(await pegar('/olts/get_all_for_select')); } catch (e) { lista = []; }
  if (!lista.length) {
    try {
      const base = '/olts/olts_list?olt_city=' + encodeURIComponent(CIDADES.join(',')) + '&sort_field=hostname&sort_order=asc&hide_deactivated=false&items=100&page=';
      let pagina = 1, total = Infinity;
      while (lista.length < total && pagina <= 20) {
        const j = await pegar(base + pagina);
        total = j.total_count || 0;
        normalizaOlts(j.olts || []).forEach(o => lista.push(o));
        if (!j.olts || !j.olts.length) break;
        pagina++;
      }
    } catch (e) { /* sem lista de OLTs: a busca segue sem restringir */ }
  } else {
    const so = lista.filter(o => COD_CIDADES_JH.test(o.hostname));
    if (so.length) lista = so;
  }
  CACHE_OLTS.lista = lista; CACHE_OLTS.ids = lista.map(o => o.id); if (lista.length) CACHE_OLTS.quando = Date.now();   // lista vazia (não logado / sem permissão) não fica guardada
  return lista;
}
async function idsOltsDaJh() { await oltsDaJh(); return CACHE_OLTS.ids; }   // pode voltar vazio: aí a busca vai sem restringir por OLT
const txt = (v, n) => v == null ? '' : String(v).slice(0, n || 200);
const FILTROS_BUSCA = { nome: 'subscriber_name', contrato: 'erp_id', pppoe: 'pppoe_username', endereco: 'address', serial: 'serial_number', int6: 'gpon_client_id' };
const semAcento = v => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
async function buscarAssinantes(f) {
  const p = new URLSearchParams();
  let algum = false;
  Object.keys(FILTROS_BUSCA).forEach(k => {
    const v = String((f && f[k]) || '').trim().slice(0, 80);
    if (v) { p.set(FILTROS_BUSCA[k], v); algum = true; }
  });
  // v1.3.0: buscar pela OLT (parte do nome, ex. "san-04") e pela PON (ex. "0/3/3"): lista os assinantes da OLT/PON
  const oltTxt = String((f && f.olt) || '').trim().slice(0, 60), pon = String((f && f.pon) || '').trim().slice(0, 20);
  let ids = null;
  if (oltTxt) {
    const partes = semAcento(oltTxt).split(/[\s\-_\/]+/).filter(Boolean);
    const todasOlts = await oltsDaJh();
    if (!todasOlts.length) throw new Error('O AutoISP não deixou listar as OLTs desta conta — busque por nome, contrato, SN ou endereço.');
    const achadas = todasOlts.filter(o => partes.every(x => semAcento(o.hostname).indexOf(x) >= 0));
    if (!achadas.length) throw new Error('Não achei OLT da JH com o nome "' + oltTxt + '".');
    if (achadas.length > 12) throw new Error('Esse nome casa com ' + achadas.length + ' OLTs — digite mais do nome da OLT.');
    ids = achadas.map(o => o.id); algum = true;
  }
  if (pon && !ids) throw new Error('Para buscar pela PON informe também a OLT.');
  if (pon) p.set('ponlink', pon);
  if (!algum) throw new Error('Digite pelo menos um filtro (nome, contrato, PPPoE, endereço, SN, Int6 ou OLT).');
  const idsBusca = ids || await idsOltsDaJh();
  if (idsBusca.length) p.set('olt_id', idsBusca.join(','));
  const j = await pegar('/client_search/search?' + p.toString());
  if (!Array.isArray(j)) throw new Error('O AutoISP respondeu num formato que eu não conheço.');
  return j.slice(0, 100).map(x => ({
    int6: txt(x.gpon_client_id, 20), contrato: txt(x.erp_id, 30), nome: txt(x.subscriber_name, 120), pppoe: txt(x.pppoe_username, 80),
    endereco: txt(x.address, 200), serial: txt(x.serial_number, 60), serial_curto: txt(x.short_serial_number, 30),
    acs: txt(x.acs_serial_number, 40), olt: txt(x.olt_hostname, 120), olt_id: txt(x.olt_id, 20), ponlink: txt(x.ponlink, 20),
  }));
}
async function detalheAssinante(int6) {
  const id = String(int6 || '').trim();
  if (!/^\d{1,12}$/.test(id)) throw new Error('Int6 inválido.');
  const j = await pegar('/gpon_clients/' + id + '/detailed_info');
  const g = j && j.gpon_client;
  if (!g) throw new Error('O AutoISP não devolveu os detalhes desse assinante.');
  const c = (g.contracted_service && g.contracted_service.contract) || {};
  const sub = c.subscriber || {};
  const st = g.onu_status || {};
  const rx = parseFloat(String(st.rx_power).replace(',', '.'));
  const co = j.coordinates && j.coordinates.client;
  return {
    int6: id, ponlink: txt(g.ponlink, 20), serial: txt(g.serial_number, 60), mac: txt(g.mac, 40), descricao: txt(g.description, 160),
    pppoe: txt(g.pppoe_username, 80), topologia: txt(g.topology, 30),
    plano: txt(g.contracted_service && g.contracted_service.service && g.contracted_service.service.service_name, 200),
    contrato: txt(c.contract_code, 30), nome: txt(sub.subsc_corp_name || sub.subsc_name, 120),
    bairro: txt(c.contract_install_addr_neigh, 80), cidade: txt(c.contract_install_addr_city, 60), uf: txt(c.contract_install_addr_state, 4),
    sinal_rx: isFinite(rx) ? rx : null, status_onu: txt(st.status, 40),
    acs_ultimo_contato: txt(g.acs_last_inform, 40), acs_serial: txt(g.acs_serial_number, 40), registro_atualizado_em: txt(g.updated_at, 40),
    macs: (Array.isArray(g.learned_macs) ? g.learned_macs : []).map(m => txt(m && m.mac, 30)).slice(0, 10),
    lat: co && isFinite(Number(co.lat)) ? Number(co.lat) : null, lng: co && isFinite(Number(co.lng)) ? Number(co.lng) : null,
    consultado_em: new Date().toISOString(),
  };
}

// ---- v1.3.0 (20/10/2026): CONECTAR / OLTs / ATUALIZAR SINAL — o AutoISP voltou ----
// status: confere se este Chrome está logado no AutoISP (uma consulta mínima, só leitura).
async function statusAutoIsp() {
  // uma busca que não acha ninguém (contrato 0): só prova que o login vale — a página de OLTs saiu do menu desta conta
  const j = await pegar('/client_search/search?erp_id=0');
  if (!Array.isArray(j)) throw new Error('O AutoISP respondeu num formato que eu não conheço.');
  let olts = null;
  try { olts = (await oltsDaJh()).length || null; } catch (e) { olts = null; }
  return { logado: true, olts };
}
async function listaDeOlts() { return (await oltsDaJh()).slice(); }
// atualizar: faz o mesmo que o botão "Atualizar" da página do assinante no AutoISP — manda a OLT ler o sinal da ONU agora
// (GET refresh_status.json), espera e lê de novo. É UM assinante por clique do usuário; nunca em lote automático.
const espera = ms => new Promise(r => setTimeout(r, ms));
async function atualizarSinal(int6) {
  const id = String(int6 || '').trim();
  if (!/^\d{1,12}$/.test(id)) throw new Error('Int6 inválido.');
  const antes = await detalheAssinante(id);
  let r;
  try { r = await fetch(BASE + '/gpon_clients/' + id + '/refresh_status.json?skip_power_graph=true', { credentials: 'include', headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' } }); }
  catch (e) { throw new Error('Não consegui falar com o AutoISP (sem internet?).'); }
  if (r.status === 401 || r.status === 403 || (r.redirected && /sign_in/.test(r.url))) throw new Error('Entre no AutoISP (auto.alloha.com) neste Chrome e tente de novo.');
  if (!r.ok) throw new Error('O AutoISP não aceitou atualizar esse assinante (resposta ' + r.status + ').');
  let depois = antes;
  for (let i = 0; i < 4; i++) {
    await espera(2500);
    depois = await detalheAssinante(id);
    if (depois.sinal_rx !== antes.sinal_rx || depois.status_onu !== antes.status_onu) break;
  }
  return { antes, depois };
}

// ---- v1.4.0 (20/10/2026): SINAIS EM LOTE — "Cliente e monitorar" e "Massivas" do U2000 ----
// Pedido do cliente: o AutoISP "conversar" com a aba Cliente e monitorar (sinal atualizado de cada ONU) e com as massivas (ver se ainda
// tem cliente caído na porta). Duas formas de achar os assinantes, sempre só GET e no máximo 3 consultas ao mesmo tempo:
//   por SN   → /client_search/search?serial_number=<SN curto>  → /gpon_clients/<int6>/detailed_info   (sinal Rx, situação, último contato)
//   por PORTA→ /client_search/search?olt_id=<OLT>&ponlink=<0/1/15>  (até 100 por PON) → o mesmo detalhe, em amostra de até 12
// `atualizar: true` manda a OLT ler cada ONU antes (o mesmo botão Atualizar do AutoISP) — só quando o usuário pede e confirma na tela.
const normSn = v => String(v || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function resumoDetalhe(d, extra) {
  return Object.assign({
    achou: true, int6: d.int6, serial: d.serial, nome: d.nome, contrato: d.contrato, ponlink: d.ponlink, bairro: d.bairro, cidade: d.cidade,
    sinal_rx: d.sinal_rx, status_onu: d.status_onu, acs_ultimo_contato: d.acs_ultimo_contato, consultado_em: d.consultado_em,
  }, extra || {});
}
async function lerSinalDe(int6, atualizar) {
  if (atualizar) { const r = await atualizarSinal(int6); return resumoDetalhe(r.depois, { sinal_antes: r.antes.sinal_rx, status_antes: r.antes.status_onu, atualizado: true }); }
  return resumoDetalhe(await detalheAssinante(int6));
}
async function sinaisPorSerial(args) {
  // v1.4.1 (20/10/2026): SEMPRE pelo SN; se o SN não aparecer na busca, tenta pelo CONTRATO (erp_id). `itens` = [{ sn, contrato }]; `serials` (lista de SN) continua valendo.
  const brutos = Array.isArray(args && args.itens) ? args.itens : (Array.isArray(args && args.serials) ? args.serials.map(sn => ({ sn })) : []);
  const itens = brutos.map(x => ({ sn: String((x && x.sn) || '').trim().slice(0, 40), contrato: String((x && x.contrato) || '').replace(/\D/g, '').slice(0, 12) })).filter(x => x.sn || x.contrato).slice(0, 12);
  if (!itens.length) throw new Error('Nenhum SN ou contrato para consultar.');
  const ids = await idsOltsDaJh();
  const buscar = async (filtro, valor) => { const p = new URLSearchParams(); p.set(filtro, valor); if (ids.length) p.set('olt_id', ids.join(',')); const j = await pegar('/client_search/search?' + p.toString()); return Array.isArray(j) ? j : []; };
  const res = await emFila(itens.map(it => async () => {
    let alvo = null, via = '';
    if (it.sn) {
      const j = await buscar('serial_number', it.sn), n = normSn(it.sn);
      alvo = j.find(x => normSn(x.short_serial_number) === n) || j.find(x => normSn(x.serial_number).indexOf(n) >= 0) || (j.length === 1 ? j[0] : null); via = 'sn';
    }
    if ((!alvo || alvo.gpon_client_id == null) && it.contrato) {
      const j = await buscar('erp_id', it.contrato);
      alvo = j.find(x => String(x.erp_id || '') === it.contrato) || j[0] || null; via = 'contrato';
    }
    if (!alvo || alvo.gpon_client_id == null) return { serial: it.sn, contrato: it.contrato, achou: false };
    return Object.assign(await lerSinalDe(alvo.gpon_client_id, !!(args && args.atualizar)), { serial: it.sn, via, olt: txt(alvo.olt_hostname, 120) });
  }), 3, () => {});
  return res.map((r, i) => (r && r.erro) ? { serial: itens[i].sn, contrato: itens[i].contrato, achou: false, erro: r.erro } : r);
}
async function sinaisPorPorta(args) {
  const nome = semAcento(args && args.olt).trim();
  if (!nome) throw new Error('Informe a OLT.');
  const todas = await oltsDaJh();
  const partes = nome.split(/[\s\-_\/]+/).filter(Boolean);
  const olt = todas.find(o => semAcento(o.hostname) === nome) || todas.find(o => partes.every(x => semAcento(o.hostname).indexOf(x) >= 0));
  if (!olt) throw new Error('Não achei a OLT "' + args.olt + '" na lista do AutoISP.');
  const frame = String((args && args.frame) == null || args.frame === '' ? 0 : args.frame), slot = String(args.slot), porta = String(args.porta);
  let lista = [], usado = '';
  for (const pon of [frame + '/' + slot + '/' + porta, slot + '/' + porta]) {
    const j = await pegar('/client_search/search?olt_id=' + encodeURIComponent(olt.id) + '&ponlink=' + encodeURIComponent(pon));
    if (Array.isArray(j) && j.length) { lista = j; usado = pon; break; }
  }
  if (!lista.length) return { olt: olt.hostname, ponlink: '', achados: 0, itens: [] };
  const limite = Math.max(1, Math.min(12, Number(args && args.limite) || 12));
  const passo = lista.length / Math.min(limite, lista.length), amostra = [];
  for (let k = 0; k < Math.min(limite, lista.length); k++) amostra.push(lista[Math.floor(k * passo)]);
  const res = await emFila(amostra.map(x => async () => Object.assign(await lerSinalDe(x.gpon_client_id, !!(args && args.atualizar)), { serial: txt(x.short_serial_number || x.serial_number, 40), olt: olt.hostname })), 3, () => {});
  return { olt: olt.hostname, ponlink: usado, achados: lista.length, itens: res.map((r, i) => (r && r.erro) ? { serial: txt(amostra[i].short_serial_number || amostra[i].serial_number, 40), achou: false, erro: r.erro } : r) };
}

// ---- ENVIAR SESSÃO (versão 1.2.0, 05/10/2026) — REMOVIDO na 1.3.0 ----
// A coleta automática da nuvem (função "autoisp") foi desativada em 14/10/2026; a ação "sessao" entregava os cookies de login
// do AutoISP pra página do sistema e não tem mais uso — saiu junto com a permissão "cookies" do manifest.
/*
// Pedido do cliente: o AutoISP "24 h", atualizado de 30 em 30 min pela nuvem, sem PC ligado. O AutoISP não
// tem API: o coletor da nuvem (Edge Function "autoisp" do Supabase) usa a MESMA sessão deste Chrome. Os
// cookies de login são HttpOnly (a página não os lê) — só uma extensão com a permissão "cookies" lê.
// Eles vão SÓ pro Supabase do próprio sistema JH (tabela trancada), por quem é Supervisor/Coordenador/Analista.
// Nenhuma senha é lida: só os cookies que o AutoISP já deixou neste navegador.
async function lerSessaoAutoIsp() {
  const lista = await chrome.cookies.getAll({ domain: 'auto.alloha.com' });
  const cookies = {};
  lista.forEach(c => { if (c && c.name && c.value) cookies[c.name] = c.value; });
  if (!Object.keys(cookies).length) throw new Error('Não há login do AutoISP neste Chrome. Entre em auto.alloha.com e tente de novo.');
  return { cookies, quantos: Object.keys(cookies).length };
}

*/
chrome.runtime.onConnect.addListener(porta => {
  if (porta.name === 'consulta-olt') {
    porta.onMessage.addListener(async m => {
      if (!m || ['buscar', 'detalhe', 'status', 'olts', 'atualizar', 'sinais', 'porta'].indexOf(m.acao) < 0) return;
      try {
        const dados = m.acao === 'buscar' ? await buscarAssinantes(m.args) : m.acao === 'detalhe' ? await detalheAssinante(m.args && m.args.int6)
          : m.acao === 'status' ? await statusAutoIsp() : m.acao === 'olts' ? await listaDeOlts() : m.acao === 'sinais' ? await sinaisPorSerial(m.args) : m.acao === 'porta' ? await sinaisPorPorta(m.args) : await atualizarSinal(m.args && m.args.int6);
        porta.postMessage({ tipo: 'jh-ext-consulta-resp', ok: true, dados });
      } catch (e) {
        try { porta.postMessage({ tipo: 'jh-ext-consulta-resp', ok: false, erro: String(e && e.message || e) }); } catch (x) { /* página fechou */ }
      }
    });
    return;
  }
  // (coleta completa das OLTs/ONUs, a de sempre)
  if (porta.name !== 'coleta-olt') return;
  porta.onMessage.addListener(async m => {
    if (!m || m.acao !== 'coletar') return;
    if (EM_ANDAMENTO) { porta.postMessage({ tipo: 'jh-ext-erro', erro: 'Já tem uma atualização em andamento — espere terminar.' }); return; }
    EM_ANDAMENTO = true;
    // as mensagens de progresso pela porta mantêm o service worker acordado (a coleta leva ~1 min)
    const avisar = (texto, pct) => { try { porta.postMessage({ tipo: 'jh-ext-progresso', texto, pct: Math.round(pct) }); } catch (e) { /* página fechou */ } };
    try {
      const dados = await coletar(avisar);
      porta.postMessage({ tipo: 'jh-ext-resultado', dados });
    } catch (e) {
      try { porta.postMessage({ tipo: 'jh-ext-erro', erro: String(e && e.message || e) }); } catch (x) { /* página fechou */ }
    } finally {
      EM_ANDAMENTO = false;
    }
  });
});
