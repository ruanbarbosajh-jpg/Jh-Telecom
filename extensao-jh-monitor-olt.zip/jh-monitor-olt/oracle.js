/* JH TELECOM — Telefones do Oracle Field Service · LEITOR + VARREDURA (roda na página do Oracle, v1.6.0)
 *
 * (1) LEITOR (desde a 1.5.0, passivo): quando uma tela "Detalhes da atividade" está aberta e traz o "Número do contrato" + os telefones, guarda no
 *     armazenamento da extensão (chrome.storage.local → "telefonesOracle", um registro por contrato). Quem leva isso pro sistema JH é a `ponte.js`.
 * (2) VARREDURA (1.6.0, pedido do cliente: "Atualizar números com o OFS" puxa os contatos de todos os clientes): só roda quando o botão do sistema
 *     pede (`ofsPedido` no storage) E a aba do Oracle está aberta. Na tela GERENCIAR (a linha do tempo do dia) ela repete, bloco por bloco:
 *       clica no bloco da atividade → clica SOMENTE no link "Detalhes" do balão (nunca em Cancelar/Suspender/Navegar…) → espera a tela de detalhes
 *       (o leitor acima guarda os telefones) → volta pelo menu global "Gerenciar".
 *     Só clica em elementos da tela, como uma pessoa; não chama endereço nenhum do Oracle, não altera atividade nenhuma. Um botão "Parar" no sistema
 *     interrompe. Estado em `ofsStatus`; a aba avisa que está aberta em `ofsAba` (a cada 4 s).
 */
(function () {
  'use strict';
  var CHAVE = 'telefonesOracle', MAX = 5000, KS = 'ofsPedido', KT = 'ofsStatus', KA = 'ofsAba', KP = 'ofsParar';
  var ROT = {
    contrato: /^n[úu]mero do contrato$/i, idCliente: /^id do cliente$/i, nome: /^nome$/i,
    celular: /^telefone celular$/i, todos: /^todos os telefones do cliente$/i, email: /^e-?mail$/i
  };
  function digitos(v) { return String(v == null ? '' : v).replace(/\D/g, ''); }
  function esp(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function campos(raiz) {
    var out = {};
    raiz.querySelectorAll('div.form-text-field').forEach(function (f) {
      var lab = f.querySelector('label'), it = f.querySelector('.form-item');
      if (!lab || !it) return;
      var t = lab.textContent.trim();
      Object.keys(ROT).forEach(function (k) { if (ROT[k].test(t) && out[k] === undefined) out[k] = { el: f, v: it.textContent.trim() }; });
    });
    return out;
  }
  function ler() {
    var c = campos(document);
    if (!c.contrato || !c.todos) return null;
    var contrato = digitos(c.contrato.v);
    if (contrato.length < 5) return null;
    var nome = '', b = c.todos.el.parentElement;
    for (var i = 0; i < 6 && b; i++, b = b.parentElement) { var cn = campos(b); if (cn.nome) { nome = cn.nome.v; break; } }
    var telefones = String(c.todos.v || '').split(/[,;\n]/).map(digitos).filter(function (d) { return d.length >= 8 && d.length <= 13; });
    var celular = c.celular ? digitos(c.celular.v) : '';
    if (!telefones.length && !celular) return null;
    return { contrato: contrato, idCliente: c.idCliente ? digitos(c.idCliente.v) : '', nome: nome, celular: celular, telefones: telefones, email: c.email ? c.email.v : '' };
  }
  var ultimo = '', timer = null;
  function guardar() {
    var r;
    try { r = ler(); } catch (e) { return false; }
    if (!r) return false;
    var assinatura = JSON.stringify(r);
    if (assinatura === ultimo) return true;
    ultimo = assinatura;
    r.em = new Date().toISOString();
    try {
      chrome.storage.local.get(CHAVE, function (res) {
        var mapa = (res && res[CHAVE]) || {};
        var a = mapa[r.contrato];
        if (a && JSON.stringify(Object.assign({}, a, { em: '' })) === JSON.stringify(Object.assign({}, r, { em: '' }))) return;
        mapa[r.contrato] = r;
        var chaves = Object.keys(mapa);
        if (chaves.length > MAX) chaves.sort(function (x, y) { return String(mapa[x].em).localeCompare(String(mapa[y].em)); }).slice(0, chaves.length - MAX).forEach(function (k) { delete mapa[k]; });
        var o = {}; o[CHAVE] = mapa;
        chrome.storage.local.set(o);
      });
    } catch (e) { /* extensão atualizada com a aba aberta: recarregar a página do Oracle resolve */ }
    return true;
  }
  function agendar() { clearTimeout(timer); timer = setTimeout(guardar, 800); }
  new MutationObserver(agendar).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  agendar();

  // ---------------------------------------------------------------- VARREDURA
  var rodando = false, ultimoPedido = '';
  function lerStorage(k) { return new Promise(function (res) { try { chrome.storage.local.get(k, function (r) { res(r ? r[k] : undefined); }); } catch (e) { res(undefined); } }); }
  function gravar(k, v) { try { var o = {}; o[k] = v; chrome.storage.local.set(o); } catch (e) { /* ver acima */ } }
  function naGerenciar() { return /^Gerenciar\./.test(document.title); }
  function naTelaDetalhes() { return /^(.{0,3})?Detalhes da atividade/.test(document.title) || !!campos(document).contrato; }
  function irParaGerenciar() {
    var a = [].slice.call(document.querySelectorAll('a.global-navigation-item')).filter(function (x) { return (x.getAttribute('title') || x.textContent || '').trim() === 'Gerenciar'; })[0];
    if (a) a.click();
    return !!a;
  }
  async function esperar(cond, ms) { var t = Date.now(); while (Date.now() - t < ms) { var v = cond(); if (v) return v; await esp(250); } return null; }
  // blocos de atividade de cliente na linha do tempo (ficam de fora almoço, folga etc.), na ordem de cima pra baixo e da esquerda pra direita
  function blocosDaLinha() {
    return [].slice.call(document.querySelectorAll('.item-block.activity')).filter(function (b) {
      return !/almo[cç]o|folga|intervalo|refei[cç]/i.test(b.textContent || '');
    }).sort(function (a, b) {
      var ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return (Math.round(ra.top / 20) - Math.round(rb.top / 20)) || (ra.left - rb.left);
    });
  }
  // SÓ o link "Detalhes" (texto exato) do balão que abriu — nunca outro
  function linkDetalhes() {
    return [].slice.call(document.querySelectorAll('span.hint_link')).filter(function (e) { return e.offsetParent !== null && (e.textContent || '').trim() === 'Detalhes'; })[0] || null;
  }
  function fecharBalao() { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true })); }
  async function deveParar() { return !!(await lerStorage(KP)); }
  function status(st) { gravar(KT, Object.assign({ atualizado: Date.now() }, st)); }

  async function varrer(pedido) {
    if (rodando) return;
    rodando = true;
    var st = { estado: 'rodando', pedido: pedido.id, feitos: 0, total: 0, lidos: 0, semTel: 0, erro: '', inicio: Date.now() };
    status(st);
    try {
      if (!naGerenciar()) { irParaGerenciar(); if (!await esperar(naGerenciar, 12000)) throw new Error('Não consegui abrir a tela Gerenciar do Oracle.'); }
      await esp(3000);
      st.total = blocosDaLinha().length; status(st);
      if (!st.total) throw new Error('Nenhuma atividade na linha do tempo (confira a data e o grupo JH TELECOM em Gerenciar).');
      for (var i = 0; i < st.total; i++) {
        if (await deveParar()) { st.estado = 'parado'; break; }
        if (!naGerenciar()) { irParaGerenciar(); await esperar(naGerenciar, 12000); await esp(2000); }
        var lista = blocosDaLinha(), b = lista[i];
        if (!b) break;
        try { b.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { /* tudo bem */ }
        b.click();
        var det = await esperar(linkDetalhes, 3500);
        if (!det) { fecharBalao(); st.feitos++; status(st); await esp(300); continue; }
        det.click();
        var abriu = await esperar(function () { return naTelaDetalhes() && campos(document).contrato; }, 9000);
        if (abriu) {
          await esp(900);
          if (guardar()) st.lidos++; else st.semTel++;
        } else { st.semTel++; }
        irParaGerenciar();
        await esperar(naGerenciar, 12000);
        await esp(1500);
        st.feitos++; status(st);
      }
      if (st.estado === 'rodando') st.estado = 'concluido';
    } catch (e) {
      st.estado = 'erro'; st.erro = String(e && e.message || e);
    } finally {
      rodando = false; st.fim = Date.now(); status(st);
    }
  }
  // o sistema pede a varredura gravando `ofsPedido` (ponte.js); cada pedido roda uma vez
  function olharPedido(p) {
    if (!p || !p.id || p.id === ultimoPedido || rodando) return;
    ultimoPedido = p.id;
    varrer(p);
  }
  try {
    chrome.storage.onChanged.addListener(function (mud, area) { if (area === 'local' && mud[KS]) olharPedido(mud[KS].newValue); });
    // aviso de que esta aba do Oracle está aberta (o sistema confere antes de pedir a varredura)
    setInterval(function () { gravar(KA, { em: Date.now(), titulo: document.title, gerenciar: naGerenciar(), rodando: rodando }); }, 4000);
    gravar(KA, { em: Date.now(), titulo: document.title, gerenciar: naGerenciar(), rodando: rodando });
  } catch (e) { /* extensão atualizada com a aba aberta */ }
})();
