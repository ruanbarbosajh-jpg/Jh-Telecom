/* JH TELECOM — Telefones do Oracle Field Service · LEITOR (roda na página do Oracle, v1.5.0)
 *
 * Pedido do cliente (22/10/2026): a tela "Detalhes da atividade" do Oracle Field Service mostra "Todos os telefones do cliente" (vários números),
 * e o CSV de atividades traz só um. Este script SÓ LÊ o que a pessoa já está vendo na tela: quando uma atividade está aberta e traz o
 * "Número do contrato" + os telefones, guarda no armazenamento da extensão (chrome.storage.local → "telefonesOracle", um registro por contrato).
 * Nada é enviado pra lugar nenhum daqui: quem leva isso pro sistema JH é a `ponte.js`, quando a aba Contatos (login Analista) pede.
 * Não faz pesquisa, não clica, não chama o Oracle: é passivo.
 */
(function () {
  'use strict';
  var CHAVE = 'telefonesOracle', MAX = 5000;
  var ROT = {
    contrato: /^n[úu]mero do contrato$/i, idCliente: /^id do cliente$/i, nome: /^nome$/i,
    celular: /^telefone celular$/i, todos: /^todos os telefones do cliente$/i, email: /^e-?mail$/i
  };
  function digitos(v) { return String(v == null ? '' : v).replace(/\D/g, ''); }
  // cada campo da tela é um <div class="form-text-field"> com <label> (rótulo) e <div class="form-item"> (valor)
  function campos(raiz) {
    var out = {};
    raiz.querySelectorAll('div.form-text-field').forEach(function (f) {
      var lab = f.querySelector('label'), it = f.querySelector('.form-item');
      if (!lab || !it) return;
      var t = lab.textContent.trim();
      Object.keys(ROT).forEach(function (k) { if (ROT[k].test(t) && out[k] === undefined) out[k] = { el: f, v: it.textContent.trim() }; });
    });
    return out;
  }
  function ler() {
    var c = campos(document);
    if (!c.contrato || !c.todos) return null;
    var contrato = digitos(c.contrato.v);
    if (contrato.length < 5) return null;
    // o "Nome" certo é o do mesmo bloco "Dados do Cliente" (sobe do campo dos telefones até achar um bloco que tenha o Nome)
    var nome = '', b = c.todos.el.parentElement;
    for (var i = 0; i < 6 && b; i++, b = b.parentElement) { var cn = campos(b); if (cn.nome) { nome = cn.nome.v; break; } }
    var telefones = String(c.todos.v || '').split(/[,;\n]/).map(digitos).filter(function (d) { return d.length >= 8 && d.length <= 13; });
    var celular = c.celular ? digitos(c.celular.v) : '';
    if (!telefones.length && !celular) return null;
    return { contrato: contrato, idCliente: c.idCliente ? digitos(c.idCliente.v) : '', nome: nome, celular: celular, telefones: telefones, email: c.email ? c.email.v : '' };
  }
  var ultimo = '', timer = null;
  function guardar() {
    var r;
    try { r = ler(); } catch (e) { return; }
    if (!r) return;
    var assinatura = JSON.stringify(r);
    if (assinatura === ultimo) return;       // mesma tela já guardada
    ultimo = assinatura;
    r.em = new Date().toISOString();
    try {
      chrome.storage.local.get(CHAVE, function (res) {
        var mapa = (res && res[CHAVE]) || {};
        var a = mapa[r.contrato];
        // só reescreve se mudou alguma coisa (a data não conta)
        if (a && JSON.stringify(Object.assign({}, a, { em: '' })) === JSON.stringify(Object.assign({}, r, { em: '' }))) return;
        mapa[r.contrato] = r;
        var chaves = Object.keys(mapa);
        if (chaves.length > MAX) chaves.sort(function (x, y) { return String(mapa[x].em).localeCompare(String(mapa[y].em)); }).slice(0, chaves.length - MAX).forEach(function (k) { delete mapa[k]; });
        var o = {}; o[CHAVE] = mapa;
        chrome.storage.local.set(o);
      });
    } catch (e) { /* extensão atualizada com a aba aberta: recarregar a página do Oracle resolve */ }
  }
  function agendar() { clearTimeout(timer); timer = setTimeout(guardar, 800); }
  new MutationObserver(agendar).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  agendar();
})();
