/* JH TELECOM — Monitoramento OLT · PONTE (roda na página do sistema JH)
 *
 * Avisa a página que a extensão está instalada ("jh-ext-presente") e, quando o botão
 * "🔄 Atualizar do AutoISP" pede ("jh-ext-coletar"), abre uma porta com o service worker
 * (background.js), que lê o AutoISP com o login deste Chrome. Progresso, resultado e erro
 * voltam pra página por postMessage — só pra própria janela, na mesma origem.
 * v1.1.0: "jh-ext-consulta" (buscar assinante / detalhe) → porta "consulta-olt" → "jh-ext-consulta-resp".
 */
(function () {
  'use strict';
  var VERSAO = chrome.runtime.getManifest().version;
  function paraPagina(msg) { window.postMessage(msg, location.origin); }
  function anunciar() { paraPagina({ tipo: 'jh-ext-presente', versao: VERSAO }); }
  anunciar();
  document.addEventListener('DOMContentLoaded', anunciar);
  window.addEventListener('message', function (ev) {
    if (ev.source !== window || ev.origin !== location.origin || !ev.data || typeof ev.data !== 'object') return;
    if (ev.data.tipo === 'jh-ext-ping') { anunciar(); return; }
    if (ev.data.tipo === 'jh-ext-consulta') {
      // consulta pontual (v1.1.0): buscar assinante / ver detalhes — uma pergunta, uma resposta
      var cid = ev.data.id, resp = false, pc;
      try { pc = chrome.runtime.connect({ name: 'consulta-olt' }); }
      catch (e) { paraPagina({ tipo: 'jh-ext-consulta-resp', id: cid, ok: false, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); return; }
      pc.onMessage.addListener(function (m) { resp = true; paraPagina(Object.assign({}, m, { id: cid })); try { pc.disconnect(); } catch (e) { /* já fechou */ } });
      pc.onDisconnect.addListener(function () { if (!resp) paraPagina({ tipo: 'jh-ext-consulta-resp', id: cid, ok: false, erro: 'A consulta foi interrompida. Tente de novo.' }); });
      pc.postMessage({ acao: ev.data.acao, args: ev.data.args });
      return;
    }
    if (ev.data.tipo !== 'jh-ext-coletar') return;
    var id = ev.data.id;
    var terminou = false;
    var porta;
    try { porta = chrome.runtime.connect({ name: 'coleta-olt' }); }
    catch (e) { paraPagina({ tipo: 'jh-ext-erro', id: id, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); return; }
    porta.onMessage.addListener(function (m) {
      if (m && (m.tipo === 'jh-ext-resultado' || m.tipo === 'jh-ext-erro')) terminou = true;
      paraPagina(Object.assign({}, m, { id: id }));
    });
    porta.onDisconnect.addListener(function () {
      if (!terminou) paraPagina({ tipo: 'jh-ext-erro', id: id, erro: 'A coleta foi interrompida. Tente de novo.' });
    });
    porta.postMessage({ acao: 'coletar' });
  });
})();
