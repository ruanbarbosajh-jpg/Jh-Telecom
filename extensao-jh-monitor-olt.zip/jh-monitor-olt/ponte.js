/* JH TELECOM — Monitoramento OLT · PONTE (roda na página do sistema JH)
 *
 * Avisa a página que a extensão está instalada ("jh-ext-presente") e, quando o botão
 * "🔄 Atualizar do AutoISP" pede ("jh-ext-coletar"), abre uma porta com o service worker
 * (background.js), que lê o AutoISP com o login deste Chrome. Progresso, resultado e erro
 * voltam pra página por postMessage — só pra própria janela, na mesma origem.
 * v1.6.0: "jh-ext-ofs-estado" / "jh-ext-ofs-varrer" / "jh-ext-ofs-parar" (varredura do Oracle).
 * v1.5.0: "jh-ext-telefones-ler" / "jh-ext-telefones-baixa" (telefones do Oracle Field Service).
 * v1.1.0: "jh-ext-consulta" (buscar assinante / detalhe) → porta "consulta-olt" → "jh-ext-consulta-resp".
 */
(function () {
  'use strict';
  var VERSAO = chrome.runtime.getManifest().version;
  function paraPagina(msg) { window.postMessage(msg, location.origin); }
  function anunciar() { paraPagina({ tipo: 'jh-ext-presente', versao: VERSAO }); }
  anunciar();
  document.addEventListener('DOMContentLoaded', anunciar);
  window.addEventListener('message', function (ev) {
    if (ev.source !== window || ev.origin !== location.origin || !ev.data || typeof ev.data !== 'object') return;
    if (ev.data.tipo === 'jh-ext-ping') { anunciar(); return; }
    // v1.5.0: telefones lidos nas telas abertas do Oracle Field Service (oracle.js guarda em chrome.storage.local → "telefonesOracle").
    // "jh-ext-telefones-ler" devolve a lista; "jh-ext-telefones-baixa" apaga o que o sistema já gravou (só se o registro não foi atualizado depois).
    if (ev.data.tipo === 'jh-ext-telefones-ler') {
      var tid = ev.data.id;
      try { chrome.storage.local.get('telefonesOracle', function (r) { paraPagina({ tipo: 'jh-ext-telefones-resp', id: tid, ok: true, itens: Object.keys((r && r.telefonesOracle) || {}).map(function (k) { return r.telefonesOracle[k]; }) }); }); }
      catch (e) { paraPagina({ tipo: 'jh-ext-telefones-resp', id: tid, ok: false, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); }
      return;
    }
    // v1.6.0: varredura do Oracle (Gerenciar → cada atividade → Detalhes). A ponte só passa recados pelo storage; quem clica é o oracle.js, na aba do Oracle.
    if (ev.data.tipo === 'jh-ext-ofs-estado' || ev.data.tipo === 'jh-ext-ofs-varrer' || ev.data.tipo === 'jh-ext-ofs-parar') {
      var oid = ev.data.id, otipo = ev.data.tipo;
      try {
        if (otipo === 'jh-ext-ofs-varrer') {
          chrome.storage.local.set({ ofsParar: false, ofsStatus: null, ofsPedido: { id: String(oid), em: Date.now() } }, function () { paraPagina({ tipo: 'jh-ext-ofs-resp', id: oid, ok: true }); });
        } else if (otipo === 'jh-ext-ofs-parar') {
          chrome.storage.local.set({ ofsParar: true }, function () { paraPagina({ tipo: 'jh-ext-ofs-resp', id: oid, ok: true }); });
        } else {
          chrome.storage.local.get(['ofsAba', 'ofsStatus'], function (r) { paraPagina({ tipo: 'jh-ext-ofs-resp', id: oid, ok: true, aba: (r && r.ofsAba) || null, status: (r && r.ofsStatus) || null }); });
        }
      } catch (e) { paraPagina({ tipo: 'jh-ext-ofs-resp', id: oid, ok: false, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); }
      return;
    }
    if (ev.data.tipo === 'jh-ext-telefones-baixa') {
      var bid = ev.data.id, gravados = Array.isArray(ev.data.itens) ? ev.data.itens : [];
      try {
        chrome.storage.local.get('telefonesOracle', function (r) {
          var m = (r && r.telefonesOracle) || {}, n = 0;
          gravados.forEach(function (g) { if (g && m[g.contrato] && m[g.contrato].em === g.em) { delete m[g.contrato]; n++; } });
          chrome.storage.local.set({ telefonesOracle: m }, function () { paraPagina({ tipo: 'jh-ext-telefones-resp', id: bid, ok: true, removidos: n }); });
        });
      } catch (e) { paraPagina({ tipo: 'jh-ext-telefones-resp', id: bid, ok: false, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); }
      return;
    }
    if (ev.data.tipo === 'jh-ext-consulta') {
      // consulta pontual (v1.1.0): buscar assinante / ver detalhes — uma pergunta, uma resposta
      var cid = ev.data.id, resp = false, pc;
      try { pc = chrome.runtime.connect({ name: 'consulta-olt' }); }
      catch (e) { paraPagina({ tipo: 'jh-ext-consulta-resp', id: cid, ok: false, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); return; }
      pc.onMessage.addListener(function (m) { resp = true; paraPagina(Object.assign({}, m, { id: cid })); try { pc.disconnect(); } catch (e) { /* já fechou */ } });
      pc.onDisconnect.addListener(function () { if (!resp) paraPagina({ tipo: 'jh-ext-consulta-resp', id: cid, ok: false, erro: 'A consulta foi interrompida. Tente de novo.' }); });
      pc.postMessage({ acao: ev.data.acao, args: ev.data.args });
      return;
    }
    if (ev.data.tipo !== 'jh-ext-coletar') return;
    var id = ev.data.id;
    var terminou = false;
    var porta;
    try { porta = chrome.runtime.connect({ name: 'coleta-olt' }); }
    catch (e) { paraPagina({ tipo: 'jh-ext-erro', id: id, erro: 'A extensão foi atualizada — recarregue a página (F5).' }); return; }
    porta.onMessage.addListener(function (m) {
      if (m && (m.tipo === 'jh-ext-resultado' || m.tipo === 'jh-ext-erro')) terminou = true;
      paraPagina(Object.assign({}, m, { id: id }));
    });
    porta.onDisconnect.addListener(function () {
      if (!terminou) paraPagina({ tipo: 'jh-ext-erro', id: id, erro: 'A coleta foi interrompida. Tente de novo.' });
    });
    porta.postMessage({ acao: 'coletar' });
  });
})();
